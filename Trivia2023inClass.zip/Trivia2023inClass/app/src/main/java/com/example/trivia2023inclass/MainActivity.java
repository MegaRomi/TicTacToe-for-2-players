package com.example.trivia2023inclass;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button btnInstruction, btnSetting, btnStartGame; // הפניות לכפתורים
    private ActivityResultLauncher<Intent> activityResultLauncher;

    private String backgroundColor = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // show activity_main.xml on the screen

        // קישור בין ההפניות לבין הרכיבים בקובץ ה xml
        btnInstruction = findViewById(R.id.btnInstruction);
        btnSetting = findViewById(R.id.btnSetting);
        btnStartGame = findViewById(R.id.btnStartGame);

        // הוספת מאזינים לכפתורים
        btnInstruction.setOnClickListener(this);
        btnSetting.setOnClickListener(this);
        btnStartGame.setOnClickListener(this);

        FirebaseModule firebaseModule = new FirebaseModule(this); //
        //firebaseModule.changeBackgroundColorInFireBase("Blue"); //todo delete

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        // The SettingActivity call back to this function
                        Intent data = result.getData();
                        String color = data.getStringExtra("color");
                        backgroundColor = color; //

                        setBackgroundColor(color); // todo fbModule.changeBackgroundColorInFireBase(str);
                        //firebaseModule.changeBackgroundColorInFireBase(color); //todo add 2

                    }
                }
        );
    }

    public void setBackgroundColor(String color) {
        //Toast.makeText(this, "color = " + color, Toast.LENGTH_SHORT).show();
        LinearLayout ll = findViewById(R.id.main_linear_layout);

        switch (color)
        {
            case "Red":
                ll.setBackgroundColor(Color.RED);
                break;

            case "Blue":
                ll.setBackgroundColor(Color.BLUE);
                break;

            case "Pink":
                ll.setBackgroundColor(Color.argb(255,255,192,203));
                //ll.setBackgroundColor(0xFFFC46AA);
                break;

                default:
                    // Yellow
                    ll.setBackgroundColor(Color.YELLOW);
                    break;

        }

    }

    @Override
    public void onClick(View v) {
        // האנדרואיד קופץ לפעולה onClick
        // כאשר המשתמש לוחץ על אחד הכפתורים
        // View v - הפניה לכפתור שהמשתמש לחץ עליו
        if(v == btnInstruction)
        {
            Intent i = new Intent(this, InstructionActivity.class);
            startActivity(i);
        }

        if(v == btnSetting)
        {
            //
            Intent intent = new Intent(this, SettingActivity.class);
            //startActivity(intent);
            activityResultLauncher.launch(intent);

        }

        if(v == btnStartGame)
        {
            // create Explecet Intent from this activity to Game activity
            Intent i = new Intent(this,GameActivity.class);

            // add putExtra and send the backgroundColor
            // TODO: 11/11/2023 hw : להוסיף שליחת צבע רקע 
            // start a new activity (transfer to Game activity)
            startActivity(i);
        }
    }
}