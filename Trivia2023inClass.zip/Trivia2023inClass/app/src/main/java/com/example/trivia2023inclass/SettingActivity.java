package com.example.trivia2023inclass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class SettingActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String[] arr = {"", "Red", "Blue", "Pink", "Yellow"};
    Spinner spinner;
    private boolean isFirstTime = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        spinner = findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);

        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item,arr);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(aa);
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(!isFirstTime)
        {
            //Toast.makeText(this, "color = " + arr[position], Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(); // מסר
            intent.putExtra("color", arr[position]); // add the color to the Intent
            setResult(RESULT_OK, intent); // send back the color to the MainActivity
            finish(); // close the settingActivity and go back to MainActivity
        }
        isFirstTime = false;

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}