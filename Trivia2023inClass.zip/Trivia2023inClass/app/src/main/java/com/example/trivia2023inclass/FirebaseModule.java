package com.example.trivia2023inclass;

import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirebaseModule {


    private MainActivity mainActivity;
    public FirebaseModule(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        initFirebaseListener();
    }

    private void initFirebaseListener() {
        // connect to firebase
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        // הפניה לצומת שרוצים לכתוב אליו
        DatabaseReference reference = firebaseDatabase.getReference("color");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String strColor = snapshot.getValue(String.class);
                Toast.makeText(mainActivity, "color = " + strColor, Toast.LENGTH_SHORT).show();
                mainActivity.setBackgroundColor(strColor);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void changeBackgroundColorInFireBase(String color) {
        // connect to firebase
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        // הפניה לצומת שרוצים לכתוב אליו
        DatabaseReference reference = firebaseDatabase.getReference("color");
        // כתיבה לצומת
        reference.setValue(color);
    }
}
