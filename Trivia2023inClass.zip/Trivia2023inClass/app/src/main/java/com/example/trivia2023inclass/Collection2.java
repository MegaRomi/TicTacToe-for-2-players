package com.example.trivia2023inclass;

import java.util.ArrayList;
import java.util.Random;

public class Collection2 {

    //  המחלקה שומרת ומנהלת את אוסף כל השאלות
    private ArrayList<Question> questions; // The ArrayList class is a resizable array
    // https://www.w3schools.com/java/java_arraylist.asp

    private Question q1,q2,q3,q4,q5;

    public Collection2()
    {
        questions = new ArrayList<Question>();

        q1 = new Question("1+10","1", "11", "3","100", 2);
        q2 = new Question("1+2", "1", "2", "3","100", 3);
        q3 = new Question("1+3", "1", "2", "4","100", 3);
        q4 = new Question("1+4", "5", "2", "3","100", 1);
        q5 = new Question("1+0", "1", "2", "3","100", 1);

    }


    public void initQuestions()
    {
        questions.clear(); // remove all the elements in the ArrayList

        questions.add (q1);
        questions.add (q2);
        questions.add (q3);
        questions.add (q4);
        questions.add (q5);
    }

    public Question getNextQuestion()
    {
        // הפעולה מחזירה הפניה לשאלה הבאה
        Random rnd = new Random();
        int index = rnd.nextInt(questions.size());
        Question q = questions.get(index);
        questions.remove(index);
        return q;
    }


    public boolean isNotLastQuestion() {
        // הפעולה מחזירה אמת אם אנו בשאלה האחרונה
        return (questions.size() > 0); // if not at the end of the ArrayList
        // }
    }


}

