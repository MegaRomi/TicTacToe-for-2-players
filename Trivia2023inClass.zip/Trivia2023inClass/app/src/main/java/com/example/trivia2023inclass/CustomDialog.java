package com.example.trivia2023inclass;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;

public class CustomDialog extends Dialog implements View.OnClickListener {
    Button btnYes, btnNo;
    private Context context;
    public CustomDialog(@NonNull Context context) {  // the Context is the pointer to the GameActivity
        super(context); // קריאה לפעולה הבונה של ה Dialog

        this.context = context;
        setContentView(R.layout.custom_dialog); // show on screen the XML file
        setTitle("Play again?");
        setCancelable(false); // false -> android doesn't close the dialog when press outside

        this.btnYes = findViewById(R.id.btnYes);
        this.btnYes.setOnClickListener(this);
        btnNo = findViewById(R.id.btnNo);
        btnNo.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == btnYes)
        {
            ((GameActivity)context).resetGame();
            dismiss(); // הפעולה מוחקת את החלוהית של הדיאלוג
        }

        if(v == btnNo)
        {
            // return to the MainActivity
            ((GameActivity)context).finish(); // finish close the Activity
        }
    }
}
