package com.example.trivia2023inclass;

public class Question {
    // מהמחלקה יוצרים עצמים
    // כאשר כל עצם שומר את כל המידע על שאלה אחת
    private String question,a1,a2,a3,a4; // שאלה ו 4 תשובות אפשריות
    private int correct; // the num of the correct answer 1 - 4, 1 = a1, 2 = a2 ....

    public Question(String question, String a1, String a2, String a3, String a4, int correct) {
        this.question = question;
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        this.a4 = a4;
        this.correct = correct;
    }

    public String getQuestion() {
        return question;
    }

    public String getA1() {
        return this.a1;
    }

    public String getA2() {
        return a2;
    }

    public String getA3() {
        return a3;
    }

    public String getA4() {
        return a4;
    }

    public int getCorrect() {
        return correct;
    }
}
