package com.example.trivia2023inclass;

import java.util.ArrayList;
import java.util.Collections;


public class Collection {
    //  המחלקה שומרת ומנהלת את אוסף כל השאלות
    private int index; // מספר השאלה הבאה בתור
    private ArrayList<Question> questions; // The ArrayList class is a resizable array
    // https://www.w3schools.com/java/java_arraylist.asp

    public Collection()
    {
        index = 0;
        questions = new ArrayList<Question>();
        Question q1 = new Question("1+10","1", "11", "3","100", 2);
        Question q2 = new Question("1+2", "1", "2", "3","100", 3);
        Question q3 = new Question("1+3", "1", "2", "4","100", 3);
        Question q4 = new Question("1+4", "5", "2", "3","100", 1);
        Question q5 = new Question("1+0", "1", "2", "3","100", 1);

        questions.add (q1);
        questions.add (q2);
        questions.add (q3);
        questions.add (q4);
        questions.add (q5);
    }

    public void initQuestions()
    {
        index = 0;
        Collections.shuffle(questions);

    }

    public Question getNextQuestion()
    {
        // הפעולה מחזירה הפניה לשאלה הבאה
        Question q = questions.get(index);
        index++;
        return q;
    }


    public boolean isNotLastQuestion() {
        // הפעולה מחזירה אמת אם אנו בשאלה האחרונה
        return (index < questions.size());
        // }
    }


}
